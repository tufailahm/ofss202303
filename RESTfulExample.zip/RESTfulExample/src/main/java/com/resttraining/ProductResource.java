package com.resttraining;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/*
http://localhost:8080/RESTfulExample/rest/products		-GET
http://localhost:8080/RESTfulExample/rest/products/1816		-GET
	*/

@Path("products") 
public class ProductResource {

	public ProductResource() {
		// TODO Auto-generated constructor stub
	}
	@GET
	@Path("msg/{guestName}") // http://localhost:8080/RESTfulExample/rest/products/msg/Ahmed
	public String getMessage(@PathParam("guestName")String gName) {
		return "Product Rest API is working!!! - Mr/Ms , "+gName ;
	}

	@GET
	@Path("{productId}") // http://localhost:8080/RESTfulExample/rest/products/123 - GET
	@Produces(MediaType.APPLICATION_JSON)
	public Product getASingleProduct(@PathParam("productId")Integer productId) {
		//code here to search for the product and return
		Product product = new Product(productId, "HPLaptop", 2900, 78000);
		return product;
	}
	
	@GET		// http://localhost:8080/RESTfulExample/rest/products- GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getAllProducts() {		//calling the dao to get the products
		List<Product> products = new ArrayList<Product>();
		products.add(new Product(122, "Bottle", 100, 2000));
		products.add(new Product(100, "HPLaptop", 2900, 78000));
		products.add(new Product(102, "HPLaptop", 2900, 78000));

		return products;
	}
}


